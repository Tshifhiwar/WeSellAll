﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace WeSellAllWebsite.Models
{
    public class ProductsViewModel
    {
        public int productId { get; set; }

        [Required]
        [StringLength(20)]
        [Display(Name = "Product Name: ")]
        public string productName { get; set; }
        public string createdDate { get; set; }

        [Required]
        [Display(Name = "Product Description: ")]
        [DataType(DataType.MultilineText)]
        public string productDescription { get; set; }

        [Required]
        [StringLength(10)]
        [Display(Name = "Price: ")]
        public string price { get; set; }

        [Display(Name = "Product Image: ")]
        public string productImage { get; set; }
        public string mimetype { get; set; }
        public int userId { get; set; }

        [Display(Name = "Product Category: ")]
        public string productCategory { get; set; }

       public int categoryId { get; set; }

    }
}
