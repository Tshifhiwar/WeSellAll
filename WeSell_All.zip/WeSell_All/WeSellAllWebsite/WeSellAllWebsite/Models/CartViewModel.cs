﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace WeSellAllWebsite.Models
{
    public class CartViewModel
    {
        public int Userid { get; set; }
        public string Amount { get; set; }
        public int Quantity { get; set; }

        [Display(Name = "Product ID: ")]
        public int ProductId { get; set; }

        [Display(Name = "Product Name: ")]
        public string ProductName { get; set; }
    }
}
