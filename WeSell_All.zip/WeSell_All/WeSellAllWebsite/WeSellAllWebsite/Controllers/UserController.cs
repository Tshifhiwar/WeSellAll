﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Threading.Tasks;
using WeSellAllWebsite.Models;
using Newtonsoft.Json;
using System.Net.Http;
using System.Text;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;

namespace WeSellAllWebsite.Controllers
{
    public class UserController : Controller
    {
        private readonly UserManager<IdentityUser> _userManager;
        private readonly SignInManager<IdentityUser> _signInManager;

        private HttpClient apiClient;
        public UserController(IHttpClientFactory factory)
        {
            apiClient = factory.CreateClient("WeSellAPI");
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Register(UserViewModel register)
        {           
            if (register.Password == register.ConfirmPassword)
            {
                using (var httpClient = new HttpClient())
                {
                    var encryptpassowrd = Base64Encode(register.Password);
                    register.Password = encryptpassowrd;

                    StringContent content = new StringContent(JsonConvert.SerializeObject(register), Encoding.UTF8, "application/json");                   
                   // using var response = await httpClient.PostAsync(url+"user/register", content);
                    using var response = await apiClient.PostAsync("user/register", content);
                    if (response.StatusCode == System.Net.HttpStatusCode.OK)
                    {                    
                        ViewBag.Message = "Success";
                    }
                    else
                    {
                        ModelState.AddModelError("", "Error creating account");
                    }
                }
                return View();
            }
            else
            {
                ModelState.AddModelError("", "Passwords do not match!");
                return View();
            }
        }

        [HttpGet]
        [AllowAnonymous]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(UserViewModel user)
        {

            if (user.EmailAddress != null && user.Password != null)
            {             
                List<UserViewModel> userdata = new List<UserViewModel>();
                using (var httpClient = new HttpClient())
                {
                    var encryptpassowrd = Base64Encode(user.Password);
                    user.Password = encryptpassowrd;

                    StringContent content = new StringContent(JsonConvert.SerializeObject(user), Encoding.UTF8, "application/json");
                    using var response = await apiClient.PostAsync("user/userlogin", content);
                    if (response.StatusCode == System.Net.HttpStatusCode.OK) { 
                        var apiResponse = await response.Content.ReadAsStringAsync();

                        userdata = JsonConvert.DeserializeObject<List<UserViewModel>>(apiResponse);

                        foreach (var userifo in userdata)
                        {
                            HttpContext.Session.SetString("UserEmail", userifo.EmailAddress);                        
                            HttpContext.Session.SetInt32("UserId", userifo.Id);
                            HttpContext.Session.SetString("ClientName", userifo.FirstName);

                            ViewBag.UserId = (int)HttpContext.Session.GetInt32("UserId");
                        }

                        return RedirectToAction("Index", "Products");
                    }
                    else
                    {
                        ModelState.AddModelError("", "Invalid username and password");
                    }
                                    
                 }
                return View(userdata);
            }
            else
            {
                ModelState.AddModelError("", "Please enter username and password");
                return View();
            }
        }

        //Simple base64 Encryption
        public static string Base64Encode(string plainText)
        {
            var plainTextBytes = Encoding.UTF8.GetBytes(plainText);
            return Convert.ToBase64String(plainTextBytes);
        }

        public static string Base64Decode(string base64EncodedData)
        {
            var base64EncodedBytes = Convert.FromBase64String(base64EncodedData);
            return Encoding.UTF8.GetString(base64EncodedBytes);
        }

        public async Task<IActionResult> Logout()
        {
            await _signInManager.SignOutAsync();

            return RedirectToAction("Login");
        }
    }
}
