﻿using System;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using WeSellAllWebsite.Models; 
using Newtonsoft.Json;
using System.IO;
using System.Net;
using System.Net.Mail;
using Microsoft.AspNetCore.Http;
using System.Text;
using Microsoft.Extensions.Options;
using System.Data;


namespace WeSellAllWebsite.Controllers
{
    public class ProductsController : Controller
    {
        private HttpClient apiClient;
        public ProductsController (IHttpClientFactory factory)
        {
            apiClient = factory.CreateClient("WeSellAPI");
        }
        public async Task<IActionResult> Index()
        {
            List<ProductsViewModel> productList = new List<ProductsViewModel>();
            using (var httpClient = new HttpClient())
            {
                using (var response = await apiClient.GetAsync("products/getproducts"))
                {
                    if (response.StatusCode == HttpStatusCode.OK)
                    {
                        string apiResponse = await response.Content.ReadAsStringAsync();
                        productList = JsonConvert.DeserializeObject<List<ProductsViewModel>>(apiResponse);
                    }
                }
            }
            return View(productList);
        }

        public IActionResult AddProducts()
        {
            return View();
        }

        //Add product and convert image into base64 and store it in db
        [HttpPost]
        public async Task<IActionResult> AddProducts(ProductsViewModel products, IFormFile productImage)
        {
            var path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", productImage.FileName);

            using (var stream = new FileStream(path, FileMode.Create))
            {
                await productImage.CopyToAsync(stream);
            }

            var mimetype = productImage.ContentType;

            using (FileStream reader = new FileStream(path, FileMode.Open))
            {
                byte[] buffer = new byte[reader.Length];
                reader.Read(buffer, 0, (int)reader.Length);
                string base64file = Convert.ToBase64String(buffer);

                products.productImage = base64file;
                products.mimetype = mimetype;

                //this should be the category ID selected on the when adding a product, it is 1 for now
                products.categoryId = 1;
                
                using (var httpClient = new HttpClient())
                {
                    StringContent content = new StringContent(JsonConvert.SerializeObject(products), Encoding.UTF8, "application/json");
                    using var response = await apiClient.PostAsync("products/addproduct", content);
                    if (response.StatusCode == HttpStatusCode.OK)
                    {                    
                        ViewBag.Message = "Success";
                    }
                    else
                    {
                        ModelState.AddModelError("", "Error adding product, try again later");
                    }
                }

               // System.IO.File.Delete(Path.Combine(path));
            }
            return View();
        }

        //Display Cart information and checkout from here
        public async Task<IActionResult> Cart()
        {
            List<CartViewModel> cartdata = new List<CartViewModel>();
            var userid  = (int)HttpContext.Session.GetInt32("UserId");
            using (var httpClient = new HttpClient())
            {
                using (var response = await apiClient.GetAsync("cart/getcart?userid=" + userid))
                {
                    if (response.StatusCode == HttpStatusCode.OK)
                    {
                        string apiResponse = await response.Content.ReadAsStringAsync();
                        cartdata = JsonConvert.DeserializeObject<List<CartViewModel>>(apiResponse);
                    }
                }
            }
            return View(cartdata);
        }

        //Save product information into the card via ajax post
        [HttpPost]
        public async Task<IActionResult> AddtoCart(CartViewModel cart, int productid, string productname, string productprice, int quantity)
        {          
            cart.Amount = productprice;
            cart.Quantity = quantity;
            cart.ProductId = productid;
            cart.ProductName = productname;
            cart.Userid = (int)HttpContext.Session.GetInt32("UserId");
           
            using (var httpClient = new HttpClient())
            {
                StringContent content = new StringContent(JsonConvert.SerializeObject(cart), Encoding.UTF8, "application/json");
                using var response = await apiClient.PostAsync("cart/addtocart", content);
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    ViewBag.Message = "Success";
                }
                else
                {
                    ModelState.AddModelError("", "Error adding product to cart, try again later");
                }
            }

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Checkout()
        {
            List<CartViewModel> cartdata = new List<CartViewModel>();
            var userid = (int)HttpContext.Session.GetInt32("UserId");
            using (var httpClient = new HttpClient())
            {
                using (var response = await apiClient.GetAsync("cart/getcart?userid=" + userid))
                {
                    if (response.StatusCode == HttpStatusCode.OK)
                    {
                        string apiResponse = await response.Content.ReadAsStringAsync();
                        cartdata = JsonConvert.DeserializeObject<List<CartViewModel>>(apiResponse);

                        var useremail = HttpContext.Session.GetString("UserEmail");
                        var clientname = HttpContext.Session.GetString("ClientName");

                        StringBuilder sb = new StringBuilder();

                        sb.Append("<p>Dear " + clientname + "</p><p>Your Order was susscessfull, below are the details</p></br />");
                        sb.Append("<table border=1>");
                        sb.Append("<tr>");
                        sb.Append("<td>Product Id</td>");
                        sb.Append("<td>Product Name</td>");
                        sb.Append("<td>Price</td>");
                        sb.Append("<td>Amount</td>");
                        sb.Append("<td>Quantity</td>");
                        sb.Append("</tr>");

                        foreach (var cartinfo in cartdata)
                        {
                            var totalamount = Convert.ToInt32(cartinfo.Amount) * cartinfo.Quantity;
                            sb.Append("<tr>");
                            sb.Append("<td>" + cartinfo.ProductId + "</td>");
                            sb.Append("<td>" + cartinfo.ProductName + "</td>");
                            sb.Append("<td>" + cartinfo.Amount + "</td>");
                            sb.Append("<td>" + totalamount + "</td>");
                            sb.Append("<td>" + cartinfo.Quantity + "</td>");
                        }
                        sb.Append("</table>");

                     

                        var senderEmail = new MailAddress("tshifhiwar@wesellall.com", "We Sell All");
                        var receiverEmail = new MailAddress(useremail, "Receiver");
                        var password = "";
                        var sub = "We Sell All | Online Order";
                        var body = sb.ToString();
                        
                        var smtp = new SmtpClient
                        {
                            Host = "smtp.localhost",
                            Port = 25,
                            EnableSsl = false,
                            
                            DeliveryMethod = SmtpDeliveryMethod.Network,
                            UseDefaultCredentials = true,
                            Credentials = new NetworkCredential(senderEmail.Address, password)
                        };
                        using (var mess = new MailMessage(senderEmail, receiverEmail)                      
                        {
                            
                            Subject = sub,
                            Body = body
                        })
                        {
                            mess.BodyEncoding = Encoding.UTF8;
                            mess.IsBodyHtml = true;
                            smtp.Send(mess);
                        }
                    }
                }
            }

            return View();
        }
    }
}
