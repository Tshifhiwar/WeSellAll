﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WeSellAllAPI.Models;
using WeSellAllAPI.Repository;

namespace WeSellAllAPI.Controllers
{
    [Route("wesellallapi/[controller]")]
    [ApiController]
    public class CartController : Controller
    {
        ISellRepository sellRepository;
        public CartController(ISellRepository _sellRepository)
        {
            sellRepository = _sellRepository;
        }

        [HttpPost]
        [Route("addtocart")]
        public async Task<IActionResult> AddtoCart([FromBody] Cart model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var cartid = await sellRepository.AddtoCart(model);
                    if (cartid > 0)
                    {
                        return Ok(cartid);
                    }
                    else
                    {
                        return NotFound();
                    }
                }
                catch (Exception)
                {

                    return BadRequest();
                }

            }

            return BadRequest();
        }

        [HttpGet]
        [Route("getcart")]
        public async Task<IActionResult> GetCart(int userid)
        {
            if (userid == 0)
            {
                return BadRequest();
            }

            try
            {
                var cart = await sellRepository.GetCart(userid);

                if (cart == null)
                {
                    return NotFound();
                }

                return Ok(cart);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }
    }
}
