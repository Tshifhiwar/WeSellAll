﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WeSellAllAPI.Models;
using WeSellAllAPI.Repository;

namespace WeSellAllAPI.Controllers
{
    [Route("wesellallapi/[controller]")]
    [ApiController]
    public class ProductsController : Controller
    {
        ISellRepository sellRepository;
        public ProductsController(ISellRepository _sellRepository)
        {
            sellRepository = _sellRepository;
        }

        [HttpGet]
        [Route("getcategories")]
        public async Task<IActionResult> GetCategories()
        {
            try
            {
                var categories = await sellRepository.GetCategories();
                if (categories == null)
                {
                    return NotFound();
                }

                return Ok(categories);
            }
            catch (Exception)
            {
                return BadRequest();
            }

        }

        [HttpGet]
        [Route("getproducts")]
        public async Task<IActionResult> GeProducts()
        {
            try
            {
                var products = await sellRepository.GetProducts();
                if (products == null)
                {
                    return NotFound();
                }

                return Ok(products);
            }
            catch (Exception)
            {
                return BadRequest();
            }

        }

        [HttpPost]
        [Route("addproduct")]
        public async Task<IActionResult> addproduct([FromBody] Products model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var productid = await sellRepository.AddProduct(model);
                    if (productid > 0)
                    {
                        return Ok(productid);
                    }
                    else
                    {
                        return NotFound();
                    }
                }
                catch (Exception)
                {

                    return BadRequest();
                }

            }

            return BadRequest();
        }

    }
}
