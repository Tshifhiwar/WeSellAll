﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WeSellAllAPI.Models;
using WeSellAllAPI.Repository;

namespace WeSellAllAPI.Controllers
{
    [Route("wesellallapi/[controller]")]
    [ApiController]

    public class UserController : ControllerBase
    {
       
        ISellRepository sellRepository;
        public UserController(ISellRepository _sellRepository)
        {
            sellRepository = _sellRepository;
        }

        [HttpPost]
        [Route("register")]
        public async Task<IActionResult> register([FromBody] Users model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var userid = await sellRepository.AddUser(model);
                    if (userid > 0)
                    {
                        return Ok(userid);
                    }
                    else
                    {
                        return NotFound(); 
                    }
                }
                catch (Exception)
                {

                    return BadRequest();
                }

            }

            return BadRequest();
        }

        [HttpPost]
        [Route("userlogin")]
        public async Task<IActionResult> UserLogin([FromBody] Users model)
        {
            if (model.EmailAddress == null && model.Password == null)
            {
                return BadRequest();
            }

            try
            {
                var user = await sellRepository.UserLogin(model.EmailAddress, model.Password);

                if (user == null)
                {
                    return NotFound();
                }

                return Ok(user);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

    }
}
