﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WeSellAllAPI.Models;
using WeSellAllAPI.ViewModel;
using Microsoft.EntityFrameworkCore;

namespace WeSellAllAPI.Repository
{
    public class SellRepository : ISellRepository
    {
        WeSellAllContext db;
        public SellRepository(WeSellAllContext _db)
        {
            db = _db;
        }

        public async Task<int> AddUser(Users user)
        {
            if (db != null)
            {
                await db.TblUsers.AddAsync(user);
                await db.SaveChangesAsync();

                return user.Id;
            }

            return 0;
        }

        public async Task<List<UserViewModel>> UserLogin(string emailaddress, string password)
        {
            if (db != null)
            {
                return await (from u in db.TblUsers
                              where u.EmailAddress == emailaddress
                              where u.Password == password
                              select new UserViewModel
                              {
                                  Id = u.Id,
                                  FirstName = u.FirstName,
                                  LastName = u.LastName,
                                  RoleId = u.RoleId,
                                  Status = u.Status,
                                  CreatedDate = u.CreatedDate,
                                  EmailAddress = u.EmailAddress
                              }).ToListAsync();
            }

            return null;
        }

        public async Task<List<Category>> GetCategories()
        {
            if (db != null)
            {
                return await db.TblCategory.ToListAsync();
            }

            return null;
        }

        public async Task<List<ProductViewModel>> GetProducts()
        {
            if (db != null)
            {
                return await (from p in db.TblProducts
                              from c in db.TblCategory
                              where p.CategoryId == c.Id
                              select new ProductViewModel
                              {
                                  ProductId = p.ProductId,
                                  ProductName = p.ProductName,
                                  Price = p.Price,
                                  ProductImage = p.ProductImage,
                                  ProductCategory = c.CategoryName,
                                  Mimetype = p.Mimetype,
                                  CreatedDate = p.CreatedDate,
                                  UserId = p.UserId,
                                  CategoryId = p.CategoryId,
                                  ProductDescription = p.ProductDescription
                              }).ToListAsync();
            }

            return null;
        }

        public async Task<int> AddProduct(Products product)
        {
            if (db != null)
            {
                await db.TblProducts.AddAsync(product);
                await db.SaveChangesAsync();

                return product.ProductId;
            }

            return 0;
        }

        public async Task<int> AddtoCart(Cart cart)
        {
            if (db != null)
            {
                await db.TblCart.AddAsync(cart);
                await db.SaveChangesAsync();

                return cart.Id;
            }

            return 0;
        }

        public async Task<List<CartViewModel>> GetCart(int userid)
        {
            if (db != null)
            {
                return await (from ca in db.TblCart
                              where ca.Userid == userid                            
                              select new CartViewModel
                              {
                                  Id = ca.Id,
                                  ProductId = ca.ProductId,
                                  ProductName = ca.ProductName,
                                  Amount = ca.Amount,
                                  Quantity = ca.Quantity,
                                  CreatedDate = ca.CreatedDate,
                                  Userid = ca.Userid
                              }).ToListAsync();
            }

            return null;
        }
    }
}
