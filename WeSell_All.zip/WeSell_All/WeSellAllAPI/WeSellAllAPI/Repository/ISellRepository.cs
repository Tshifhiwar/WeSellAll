﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WeSellAllAPI.Models;
using WeSellAllAPI.ViewModel;

namespace WeSellAllAPI.Repository
{
    public interface ISellRepository
    {
        Task<int> AddUser(Users user);
        Task<List<UserViewModel>> UserLogin(string emailaddress, string password);
        Task<int> AddProduct(Products product);
        Task<List<ProductViewModel>> GetProducts();
        Task<List<Category>> GetCategories();
        Task<int> AddtoCart(Cart cart);
        Task<List<CartViewModel>> GetCart(int userid);
    }
}
