﻿using System;
using System.Collections.Generic;

namespace WeSellAllAPI.Models
{
    public partial class Products
    {
        public int ProductId { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string ProductName { get; set; }
        public string ProductDescription { get; set; }
        public string Price { get; set; }
        public int? CategoryId { get; set; }
        public string ProductImage { get; set; }
        //public string ProductCategory { get; set; }
        public string Mimetype { get; set; }
        public int? UserId { get; set; }
    }
}
