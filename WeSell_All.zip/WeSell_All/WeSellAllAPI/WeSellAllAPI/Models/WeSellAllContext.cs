﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace WeSellAllAPI.Models
{
    public partial class WeSellAllContext : DbContext
    {
        public WeSellAllContext()
        {
        }

        public WeSellAllContext(DbContextOptions<WeSellAllContext> options)
            : base(options)
        {
        }

   
        public virtual DbSet<Products> TblProducts { get; set; }
        public virtual DbSet<Users> TblUsers { get; set; }
        public virtual DbSet<Category> TblCategory { get; set; }
        public virtual DbSet<Cart> TblCart { get; set; }

        /* protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
         {
             if (!optionsBuilder.IsConfigured)
             {
 #warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                 optionsBuilder.UseSqlServer("Server=10.1.1.127;Database=FileShare;UID=sa;PWD=Net1Bingo1;");
             }
         }*/

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
                       
            modelBuilder.Entity<Products>(entity =>
            {
                entity.HasKey(e => e.ProductId);

                entity.ToTable("tblProducts");

                entity.Property(e => e.ProductId).HasColumnName("productId");

                entity.Property(e => e.CategoryId).HasColumnName("categoryId");

                entity.Property(e => e.CreatedDate)
                    .HasColumnName("createdDate")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Mimetype)
                    .HasColumnName("mimetype")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Price)
                    .HasColumnName("price")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.ProductDescription)
                    .HasColumnName("productDescription")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ProductImage)
                    .HasColumnName("productImage")
                    .IsUnicode(false);

                entity.Property(e => e.ProductName)
                    .HasColumnName("productName")
                    .HasMaxLength(30);

                entity.Property(e => e.UserId).HasColumnName("userId");
            });

            modelBuilder.Entity<Category>(entity =>
            {
                entity.HasKey(e => e.Id);

                entity.ToTable("tblCategory");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.CategoryName).HasColumnName("categoryName");
              
            });

            modelBuilder.Entity<Users>(entity =>
            {
                entity.ToTable("tblUsers");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.CreatedDate)
                    .HasColumnName("createdDate")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EmailAddress)
                    .HasColumnName("emailAddress")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FirstName)
                    .HasColumnName("firstName")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.LastName)
                    .HasColumnName("lastName")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Password)
                    .HasColumnName("password")
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.RoleId).HasColumnName("roleId");

                entity.Property(e => e.Status).HasColumnName("status");
            });

            modelBuilder.Entity<Cart>(entity =>
            {
                entity.ToTable("tblCart");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.CreatedDate)
                    .HasColumnName("createdDate")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Userid).HasColumnName("userid");
                   
                entity.Property(e => e.Amount)
                    .HasColumnName("amount")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Quantity).HasColumnName("quantity");

                entity.Property(e => e.ProductId).HasColumnName("productid");

                entity.Property(e => e.ProductName)
                    .HasColumnName("productName")
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });
        }
    }
}
